package InfoSystem;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class MainForm{

	private JFrame frame;
	private JTextField FieldStudentNo, FieldSurname, FieldFirstName, FieldMiddleName, FieldHomeAddress, 
                FieldPermanentAddress, FieldNationality, FieldBirthdate, FieldReligion, FieldContact;
        private JLabel lblSurname, lblStudentNo, lblFirstName, lblMiddleName, lblHomeAddress, lblPermanentAddress,lblSection,
                lblBirthdate, lblGender, lblStatus , lblNationality, lblReligion, lblContactNo, lblCourse, lblYear;
	private JComboBox CourseComboBox, GenderComboBox, StatusComboBox, YearComboBox, SectionComboBox;
        private JButton btnSave, btnUpdate,btnSearch,btnDelete,btnCancel; 

	public static void main(String [] args) {
		EventQueue.invokeLater(new Runnable() {
                        @Override
			public void run() {
				try {
					MainForm window = new MainForm();
					window.frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
                
		Connection conn = null;
		try {
			conn = (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/information_system","root","");
			if(conn!=null) {
				System.out.println("Database is connected");
			}
		}catch(SQLException ex){
			System.out.println("Database is not connected");
		}
	}

	
	public MainForm() {
		initialize();
	}

	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 510, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("STUDENT INFORMATION SYSTEM");
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
                frame.setVisible(true);
                frame.setResizable(false);
		
		lblStudentNo = new JLabel("Student No");
		lblStudentNo.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblStudentNo.setBounds(10, 25, 150, 14);
		frame.getContentPane().add(lblStudentNo);
		
		FieldStudentNo = new JTextField();
		FieldStudentNo.setBounds(10, 50, 150, 20);
		frame.getContentPane().add(FieldStudentNo);
		FieldStudentNo.setColumns(10);
                        
                
                try{
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/information_system","root","");
                            String sql = "SELECT MAX(student_no) from student";
                            java.sql.Statement stmt = conn.createStatement();
                            java.sql.ResultSet rs = stmt.executeQuery(sql);
                            if(rs.next()){
                                int lastStudentNo = rs.getInt(1);
                                lastStudentNo++;
                                FieldStudentNo.setText(Integer.toString(lastStudentNo));
                                System.out.println("Last Student No: " + lastStudentNo);
                            }    
                    }catch (SQLException ex){
                        System.out.println(ex.getMessage());
                    }
                
		
		lblSurname = new JLabel("Surname");
		lblSurname.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblSurname.setBounds(10, 81, 150, 14);
		frame.getContentPane().add(lblSurname);
                         
		
		FieldSurname = new JTextField();
		FieldSurname.setColumns(10);
		FieldSurname.setBounds(10, 106, 150, 20);
		frame.getContentPane().add(FieldSurname);
               
		lblFirstName = new JLabel("First Name");
		lblFirstName.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblFirstName.setBounds(170, 82, 150, 14);
		frame.getContentPane().add(lblFirstName);
		
		FieldFirstName = new JTextField();
		FieldFirstName.setColumns(10);
		FieldFirstName.setBounds(170, 106, 150, 20);
		frame.getContentPane().add(FieldFirstName);
		
		lblMiddleName = new JLabel("Middle Name");
		lblMiddleName.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblMiddleName.setBounds(330, 82, 150, 14);
		frame.getContentPane().add(lblMiddleName);
		
		FieldMiddleName = new JTextField();
		FieldMiddleName.setColumns(10);
		FieldMiddleName.setBounds(330, 106, 150, 20);
		frame.getContentPane().add(FieldMiddleName);
		
		lblHomeAddress = new JLabel("Home Address");
		lblHomeAddress.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblHomeAddress.setBounds(10, 137, 150, 14);
		frame.getContentPane().add(lblHomeAddress);
		
		FieldHomeAddress = new JTextField();
		FieldHomeAddress.setColumns(10);
		FieldHomeAddress.setBounds(10, 162, 470, 20);
		frame.getContentPane().add(FieldHomeAddress);
		
		lblPermanentAddress = new JLabel("Permanent Address");
		lblPermanentAddress.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblPermanentAddress.setBounds(10, 193, 150, 14);
		frame.getContentPane().add(lblPermanentAddress);
		
		FieldPermanentAddress = new JTextField();
		FieldPermanentAddress.setColumns(10);
		FieldPermanentAddress.setBounds(10, 218, 470, 20);
		frame.getContentPane().add(FieldPermanentAddress);
		
		lblBirthdate = new JLabel("Birthdate(YYYY-MM-DD)");
		lblBirthdate.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblBirthdate.setBounds(10, 249, 150, 14);
		frame.getContentPane().add(lblBirthdate);
		
		FieldBirthdate = new JTextField();
		FieldBirthdate.setColumns(10);
		FieldBirthdate.setBounds(10, 274, 150, 20);
		frame.getContentPane().add(FieldBirthdate);
		
		lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblGender.setBounds(170, 249, 150, 14);
		frame.getContentPane().add(lblGender);
		
		String gender[]={"","MALE","FEMALE"}; 
		GenderComboBox = new JComboBox(gender);
		GenderComboBox.setBounds(170, 273, 150, 22);
		frame.getContentPane().add(GenderComboBox);
		
		lblStatus = new JLabel("Status");
		lblStatus.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblStatus.setBounds(330, 249, 150, 14);
		frame.getContentPane().add(lblStatus);
		
		String status[]={"","SINGLE","MARRIED","wIDOW"};
		StatusComboBox = new JComboBox(status);
		StatusComboBox.setBounds(330, 273, 150, 22);
		frame.getContentPane().add(StatusComboBox);
		
		lblNationality = new JLabel("Nationality");
		lblNationality.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblNationality.setBounds(10, 305, 150, 14);
		frame.getContentPane().add(lblNationality);
		
		FieldNationality = new JTextField();
		FieldNationality.setColumns(10);
		FieldNationality.setBounds(10, 330, 150, 20);
		frame.getContentPane().add(FieldNationality);
		
		lblReligion = new JLabel("Religion");
		lblReligion.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblReligion.setBounds(170, 306, 150, 14);
		frame.getContentPane().add(lblReligion);
		
		FieldReligion = new JTextField();
		FieldReligion.setColumns(10);
		FieldReligion.setBounds(170, 330, 150, 20);
		frame.getContentPane().add(FieldReligion);
		
		lblContactNo = new JLabel("Contact No");
		lblContactNo.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblContactNo.setBounds(330, 306, 150, 14);
		frame.getContentPane().add(lblContactNo);
		
		FieldContact = new JTextField();
		FieldContact.setColumns(10);
		FieldContact.setBounds(330, 330, 150, 20);
		frame.getContentPane().add(FieldContact);
		
		lblCourse = new JLabel("Course");
		lblCourse.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblCourse.setBounds(10, 361, 150, 14);
		frame.getContentPane().add(lblCourse);
		
		String course[]={"","BSCS", "BSIT", "BSIS", "BSEMC"};
		CourseComboBox = new JComboBox(course);
		CourseComboBox.setBounds(10, 386, 150, 22);
		frame.getContentPane().add(CourseComboBox);
		
		lblYear = new JLabel("Year");
		lblYear.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblYear.setBounds(170, 361, 150, 14);
		frame.getContentPane().add(lblYear);
		
		String year[]={"","1ST YEAR", "2ND YEAR", "3RD YEAR", "4TH YEAR"};
		YearComboBox = new JComboBox(year);
		YearComboBox.setBounds(170, 386, 150, 22);
		frame.getContentPane().add(YearComboBox);
		
		lblSection = new JLabel("Section");
		lblSection.setFont(new Font("Trebuchet MS", Font.BOLD, 13));
		lblSection.setBounds(330, 361, 150, 14);
		frame.getContentPane().add(lblSection);
		
		String section[]={"","A", "B", "C"};
		SectionComboBox = new JComboBox(section);
		SectionComboBox.setBounds(330, 386, 150, 22);
		frame.getContentPane().add(SectionComboBox);
		
		btnSearch = new JButton("SEARCH");
		btnSearch.setBounds(10, 427, 86, 23);
		frame.getContentPane().add(btnSearch);
                btnSearch.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try{
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/information_system","root","");
                            java.sql.Statement stmt = conn.createStatement();
                            int id = Integer.parseInt(FieldStudentNo.getText());

                            String sql = "SELECT * FROM student WHERE student_no=" + id + "";

                            java.sql.ResultSet rs = stmt.executeQuery(sql);
                            if (rs.next()) {
                                FieldSurname.setText(rs.getString("last_name"));
                                FieldFirstName.setText(rs.getString("first_name"));
                                FieldMiddleName.setText(rs.getString("middle_name"));
                                FieldHomeAddress.setText(rs.getString("home_add"));
                                FieldPermanentAddress.setText(rs.getString("permanent_add"));
                                FieldBirthdate.setText(rs.getString("birthday"));
                                GenderComboBox.setSelectedItem(rs.getString("gender"));
                                StatusComboBox.setSelectedItem(rs.getString("status"));
                                FieldNationality.setText(rs.getString("nationality"));
                                FieldReligion.setText(rs.getString("religion"));
                                FieldContact.setText(rs.getString("contact_no"));
                                CourseComboBox.setSelectedItem(rs.getString("course"));
                                YearComboBox.setSelectedItem(rs.getString("year"));
                                SectionComboBox.setSelectedItem(rs.getString("section"));
                                
                                System.out.println("Record Searched");
                                btnSave.setEnabled(false);
                                
                            } else {
                                JOptionPane.showMessageDialog(null, "No Record Found", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                                System.out.println("No Record Found");
                        }
                    }catch (SQLException ex){
                    System.out.println(ex.getMessage());
                    }
                }
            });
		
		btnSave = new JButton("SAVE");
		btnSave.setBounds(106, 427, 86, 23);
		frame.getContentPane().add(btnSave);
                btnSave.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/information_system","root","");
                            java.sql.Statement stmt = conn.createStatement();

                            String lname = FieldSurname.getText();
                            String fname = FieldFirstName.getText();
                            String mname = FieldMiddleName.getText();
                            String homeadd = FieldHomeAddress.getText();
                            String permanentadd = FieldPermanentAddress.getText();
                            String birth = FieldBirthdate.getText();
                            String gender = GenderComboBox.getSelectedItem().toString();
                            String status = StatusComboBox.getSelectedItem().toString();
                            String nation = FieldNationality.getText();
                            String religion = FieldReligion.getText();
                            String contact = FieldContact.getText();
                            String course = CourseComboBox.getSelectedItem().toString();
                            String year = YearComboBox.getSelectedItem().toString();
                            String section = SectionComboBox.getSelectedItem().toString();
                            String sql = "INSERT INTO student (last_name, first_name, middle_name, home_add, permanent_add, birthday, gender, status, nationality, religion, contact_no, course, year, section)"+ "VALUES ('" + lname + "', '" + fname + "' , '" + mname + "', '" + homeadd + "', '" + permanentadd + "','" + birth + "', '" + gender + "', '" + status + "', '" + nation + "', '" + religion + "', '" + contact + "', '" + course + "', '" + year + "', '" + section + "')";
                            stmt.execute(sql);
                            System.out.println("New Record Added");
                            JOptionPane.showMessageDialog(null, "Record Added", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                            MainForm.main(null);
                            frame.dispose();
                        } catch (SQLException ex) {
                             System.out.println(ex.getMessage());;
                    }
                    }
                
                }) ;
		
		btnUpdate = new JButton("UPDATE");
		btnUpdate.setBounds(202, 427, 86, 23);
		frame.getContentPane().add(btnUpdate);
                btnUpdate.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                    try {
                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/information_system","root","");
                        java.sql.Statement stmt = conn.createStatement();

                            String lname = FieldSurname.getText();
                            String fname = FieldFirstName.getText();
                            String mname = FieldMiddleName.getText();
                            String homeadd = FieldHomeAddress.getText();
                            String permanentadd = FieldPermanentAddress.getText();
                            String birth = FieldBirthdate.getText();
                            String gender = GenderComboBox.getSelectedItem().toString();
                            String status = StatusComboBox.getSelectedItem().toString();
                            String nation = FieldNationality.getText();
                            String religion = FieldReligion.getText();
                            String contact = FieldContact.getText();
                            String course = CourseComboBox.getSelectedItem().toString();
                            String year = YearComboBox.getSelectedItem().toString();
                            String section = SectionComboBox.getSelectedItem().toString();
                            int id = Integer.parseInt(FieldStudentNo.getText());

                        String sql = "UPDATE student SET last_name='" + lname + "', first_name='" + fname + "', middle_name='" + mname + "',home_add='" + homeadd + "', permanent_add='" + permanentadd+ "', birthday='" + birth + "',gender='" + gender + "', status='" + status + "', nationality='" + nation + "', religion='" + religion + "', contact_no='" + contact + "', course='" + course + "', year='" + year + "', section='" + section + "'WHERE student_no=" + id + "";
                        stmt.execute(sql);

                        System.out.println("Record Updated");
                        JOptionPane.showMessageDialog(null, "Record Updated", "Updated", JOptionPane.INFORMATION_MESSAGE);
                        btnSearch.setEnabled(false);
                        btnSave.setEnabled(false);
                        btnDelete.setEnabled(false);
                        MainForm.main(null);
                        frame.dispose();
                    }catch (SQLException ex){
                    System.out.println(ex.getMessage());
                    }
                }
            });

		
		btnDelete = new JButton("DELETE");
		btnDelete.setBounds(298, 427, 86, 23);
		frame.getContentPane().add(btnDelete);
                btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                    int res = JOptionPane.showOptionDialog(new JFrame(), "Do you really  want to delete this record?","Confirmation",
                   JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                            new Object[] { "Yes", "No" }, JOptionPane.YES_OPTION);
                                if (res == JOptionPane.YES_OPTION) {
                                    try {
                                        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/information_system","root","");
                                        java.sql.Statement stmt = conn.createStatement();
                                        int id = Integer.parseInt(FieldStudentNo.getText());
                                        String sql = "DELETE FROM student  WHERE student_no =" + id + "";
                                        stmt.execute(sql);
                                        System.out.println("Record Deleted");
                                        MainForm.main(null);
                                        frame.dispose();
                                    } catch (SQLException ex){
                                        System.out.println(ex.getMessage());
                                        }
                                } else if (res == JOptionPane.NO_OPTION) {
				        System.out.println("Selected No!");
				    }     
            }
        });
                
		
		btnCancel = new JButton("CANCEL");
		btnCancel.setBounds(394, 427, 86, 23);
		frame.getContentPane().add(btnCancel);
                btnCancel.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                                
                                
                                 int res = JOptionPane.showOptionDialog(new JFrame(), "Are you really want to cancel transaction","Confirmation",
                   JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                            new Object[] { "Yes", "No" }, JOptionPane.YES_OPTION);
                                if (res == JOptionPane.YES_OPTION) {
                                    FieldSurname.setText("");
                                    FieldFirstName.setText("");
                                    FieldMiddleName.setText("");
                                    FieldHomeAddress.setText("");
                                    FieldPermanentAddress.setText("");
                                    FieldBirthdate.setText("");
                                    GenderComboBox.setSelectedItem("");
                                    StatusComboBox.setSelectedItem("");
                                    FieldNationality.setText("");
                                    FieldReligion.setText("");
                                    FieldContact.setText("");
                                    CourseComboBox.setSelectedItem("");
                                    YearComboBox.setSelectedItem("");
                                    SectionComboBox.setSelectedItem("");
                                    System.out.println("Record Cleared");
                                } else if (res == JOptionPane.NO_OPTION) {
				        System.out.println("Selected No!");
				    }      
                  }
            });
    


	}
}
